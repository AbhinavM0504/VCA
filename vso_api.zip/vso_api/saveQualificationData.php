<?php
include 'init.php';
// Check connection
if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
  { 
  $json = json_decode(file_get_contents('php://input'),true);
   
    $userid = $json["userid"]; 
    $value = $json["value"]; 
    $name = $json["name"]; 
    $school = $json["school"]; 
    $percentage = $json["percentage"]; 
    $board = $json["board"]; 
    $yearOfPassing = $json["yearOfPassing"]; 
    $course = $json["course"]; 
    $image = $json["image"];
 
    $response = array();
 
    $check_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
    $check_result = $conn->query($check_sql);
    if ($check_result->num_rows > 0) {
        $decodedImage = base64_decode("$image");
    
        // $folder = "/home/otqje8rkxco5/public_html/wp-content/themes/oceanwp/upload/";
        $folder = "../upload/";
        $return = file_put_contents($folder.$name, $decodedImage);
     
        if($return !== false){
            $response['success'] = 1;
            $response['message'] = "Yes";
            // $image_link = "http://www.vivorajonbording.com/wp-content/themes/oceanwp/upload/";
            $image_link = "https://vivorajonbording.com/api/upload/";
            
            if($value=='image_10'){
                $sql = "UPDATE `employee_personal_detail` SET 
                        `10_school`='".$school."', 
                        `10_board`='".$board."', 
                        `10_percentage`='".$percentage."', 
                        `10_year_passing`='".$yearOfPassing."',
                    	`10_image`='".$image_link.$name."'
                    	 WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='image_12'){
                $sql = "UPDATE `employee_personal_detail` SET 
                        `12_choice`='yes',
                        `12_school`='".$school."', 
                        `12_board`='".$board."', 
                        `12_percentage`='".$percentage."', 
                        `12_year_passing`='".$yearOfPassing."',
                    	`12_image`='".$image_link.$name."'
                    	 WHERE `userid`='".$userid."'";
        	    mysqli_query($conn, $sql);
            }
            if($value=='image_g'){
                $sql = "UPDATE `employee_personal_detail` SET 
                        `graduation_choice`='yes',
                        `graduation_course`='".$course."', 
                        `graduation_university`='".$school."', 
                        `graduation_board`='".$board."', 
                        `graduation_percentage`='".$percentage."', 
                        `graduation_year_passing`='".$yearOfPassing."',
                    	`graduation_image`='".$image_link.$name."'
                    	 WHERE `userid`='".$userid."'";
            	mysqli_query($conn, $sql);
            }
            if($value=='image_pg'){
                $sql = "UPDATE `employee_personal_detail` SET 
                        `post_graduation_choice`='yes',
                        `post_graduation_course`='".$course."', 
                        `post_graduation_university`='".$school."', 
                        `post_graduation_board`='".$board."', 
                        `post_graduation_percentage`='".$percentage."', 
                        `post_graduation_year_passing`='".$yearOfPassing."',
                    	`post_graduation_image`='".$image_link.$name."'
                    	 WHERE `userid`='".$userid."'";
            	mysqli_query($conn, $sql);
            }
            if($value=='image_other'){
                $sql = "UPDATE `employee_personal_detail` SET 
                        `other_qualification_choice`='yes',
                        `other_qualification_course`='".$course."', 
                        `other_qualification_university`='".$school."', 
                        `other_qualification_board`='".$board."', 
                        `other_qualification_percentage`='".$percentage."', 
                        `other_qualification_year_passing`='".$yearOfPassing."',
                    	`other_qualification_image`='".$image_link.$name."'
                    	 WHERE `userid`='".$userid."'";
            	mysqli_query($conn, $sql);
            }
        }else{
            $response['success'] = 0;
            $response['message'] = "Image Uploaded Failed";
        }
     
        echo json_encode($response);   
    }
    else{
        $response['message'] = "Please add personal details first";
        echo json_encode($response);  
    }
   
  }
?>