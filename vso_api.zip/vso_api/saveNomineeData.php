<?php 
    include 'init.php';
    
    //Person details params
    $userid = $_POST['userid'];
    
    //father details
    $father = 'Father';//$_POST['father'];
    $fatherName = $_POST['fatherName'];
    $fatherDob = $_POST['fatherDob'];
    $fatherAmt = $_POST['fatherAmt'];
    
    //mother details
    $mother = 'Mother';//$_POST['mother'];
    $motherName = $_POST['motherName'];
    $motherDob = $_POST['motherDob'];
    $motherAmt = $_POST['motherAmt'];
    
    //wife details
    $wife = 'Spouse';//$_POST['wife'];
    $wifeName = $_POST['wifeName'];
    $wifeDob = $_POST['wifeDob'];
    $wifeAmt = $_POST['wifeAmt'];
    
    //guardian details
    $guardian_relation = 'Guardian';//$_POST['wife'];
    $guardianName = $_POST['guardianName'];
    $guardianDob = $_POST['guardianDob'];
    $guardianAmt = $_POST['guardianAmt'];
    
    //sibling details
    $sibling_relation = $_POST['sibling'];
    $siblingName = $_POST['siblingName'];
    $siblingDob = $_POST['siblingDob'];
    $siblingAmt = $_POST['siblingAmt'];
    
    //child one details
    $childOne = 'child_one';//$_POST['childOne'];
    $childOneName = $_POST['childOneName'];
    $childOneDob = $_POST['childOneDob'];
    $childOneAmt = $_POST['childOneAmt'];
    
    //child two details
    $childTwo = 'child_two';//$_POST['childTwo'];
    $childTwoName = $_POST['childTwoName'];
    $childTwoDob = $_POST['childTwoDob'];
    $childTwoAmt = $_POST['childTwoAmt'];
    
    
    //checking empty condition for params
    if(isset($userid)){
        $check_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
        $check_result = $conn->query($check_sql);
        if ($check_result->num_rows > 0) {
            $update_sql = "UPDATE `employee_personal_detail` 
                SET `father_relation`='".$father."',
                    `father_n_name`='".$fatherName."',
                    `father_dob`='".$fatherDob."',
                    `father_amount`='".$fatherAmt."',
                    `mother_relation`='".$mother."',
                    `mother_n_name`='".$motherName."',
                    `mother_dob`='".$motherDob."',
                    `mother_amount`='".$motherAmt."',
                    `wife_relation`='".$wife."',
                    `wife_n_name`='".$wifeName."',
                    `wife_dob`='".$wifeDob."',
                    `wife_amount`='".$wifeAmt."',
                    `guardian_relation`='".$guardian_relation."',
                    `guardian_name`='".$guardianName."',
                    `guardian_dob`='".$guardianDob."',
                    `guardian_amount`='".$guardianAmt."',
                    `sibling_relation`='".$sibling_relation."',
                    `sibling_name`='".$siblingName."',
                    `sibling_dob`='".$siblingDob."',
                    `sibling_amount`='".$siblingAmt."',
                    `child_one_relation`='".$childOne."',
                    `child_one_name`='".$childOneName."',
                    `child_one_dob`='".$childOneDob."',
                    `child_one_amount`='".$childOneAmt."',
                    `child_two_relation`='".$childTwo."',
                    `child_two_name`='".$childTwoName."',
                    `child_two_dob`='".$childTwoDob."',
                    `child_two_amount`='".$childTwoAmt."'
                    WHERE `userid`='".$userid."'";
                
        	if(mysqli_query($conn, $update_sql))
        	{
        		echo 'Nominee details has been saved successfully...';
        	}
        	else
        	{
        		echo "Unable to save nominee data !!!";
        	}   
        }
        else{
            echo "Please add personal details first";  
        }
    }
    else
    {
    	echo "Fields are empty";
    }
    mysqli_close($conn);
?>