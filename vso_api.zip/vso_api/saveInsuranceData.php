<?php 
    include 'init.php';
    
    //set time zone
    date_default_timezone_set("Asia/Calcutta");
    
    
    //function for uplaod image
    function uploadImage($image, $imageName){
        $decodedImage = base64_decode("$image");
        $folder = "../upload/";
        $return = file_put_contents($folder.$imageName, $decodedImage);
     
        if($return !== false){
            return true;
        }
        return false;
    }
    
    $response = array();
    
    // Check connection
    if (mysqli_connect_errno())
    {
        $response['status'] = false;
        $response['message'] = mysqli_connect_error();
        //echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    else
    { 
        $json = json_decode(file_get_contents('php://input'),true);
       
        $userid = $json["userid"]; 
        $acFrontImage = $json["acFrontImage"]; 
        $acFrontImageName = $json["acFrontImageName"]; 
        $acBackImage = $json["acBackImage"]; 
        $acBackImageName = $json["acBackImageName"]; 
        $memberRelation = $json["memberRelation"]; 
        $memberName = $json["memberName"]; 
        $memberDob = $json["memberDob"]; 
        
        $response = array();
        $check_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
        $check_result = $conn->query($check_sql);
        if ($check_result->num_rows > 0) {
            
            //check member relation if already added or not
            $check_member_sql = "SELECT * FROM `employee_insurance_table` WHERE `userid` = '".$userid."' AND `member_relation`='".$memberRelation."'";
            $check_member_result = $conn->query($check_member_sql);
            if($check_member_result->num_rows > 0){
                $response['status'] = false;
                $response['message'] = "This member has already been insured..";
            }
            else{
                $image_link = "https://vivorajonbording.com/api/testUpload/";
                //save insurance data
                if(uploadImage($acFrontImage, $acFrontImageName)){//save aadhar card front image
            
                    if(uploadImage($acBackImage, $acBackImageName)){//save aadhar card back image
                        //save insurance data
                        $time = date('Y-m-d H:i:s');
                        $sql = "INSERT INTO `employee_insurance_table`(`userid`, `member_relation`, `member_name`, `member_dob`, `member_ac_front_image`, `member_ac_back_image`, `time`) VALUES
                            ('".$userid."','".$memberRelation."','".$memberName."','".$memberDob."','".$image_link.$acFrontImageName."', '".$image_link.$acBackImageName."', '".$time."')";
                        if(mysqli_query($conn, $sql)){
                            $response['status'] = true;
                            $response['message'] = "Insurance data has been saved successfully...";
                        }
                    }
                    else{
                        $response['status'] = false;
                        $response['message'] = "Unable to upload aadhar card back image";
                    }
                }
                else{
                    $response['status'] = false;
                    $response['message'] = "Unable to upload aadhar card front image";
                }
            }
           
        }
        else{
            $response['status'] = false;
            $response['message'] = "Please add personal details first";
        }
    }
    echo json_encode($response); 
?>