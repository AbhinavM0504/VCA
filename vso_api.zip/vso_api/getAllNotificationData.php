<?php
    include 'init.php';

    $userid = $_POST['userid'];

    $notificationData = array();
    $response = array();
    
    if(isset($userid)){
        $get_data_sql = "SELECT * FROM `employee_notification_table` WHERE `userid` = '".$userid."' order by id desc";
    	$result = $conn->query($get_data_sql);
    	
    	
    	if ($result->num_rows > 0) {
	        $updateSql = "Update `employee_notification_table` SET `notification_status` = 'Seen' WHERE `userid` = '".$userid."'";
    	    $updateResult = $conn->query($updateSql);
    	    
    	    while($row = $result->fetch_assoc()) 
    	    {
	            $temp = [
        		    'notificationId'=>"".$row["id"]."",
    		        'notificationTitle'=>"".$row["notification_title"]."",
        		    'notificationDate'=>"".$row["time"]."",
        		    'notificationText'=>"".$row["notification_text"].""
    		    ];
	 
	            array_push($notificationData, $temp);
    	    }
    	    $response['status'] = true;
    	    $response['message'] = $notificationData;
    	}
    	else {
            $response['status'] = false;
    	    $response['message'] = "No data available";
        }
    }
    else {
        $response['status'] = false;
	    $response['message'] = "Invalid User";
    }   
    
    echo json_encode($response);
    mysqli_close($conn);
?>