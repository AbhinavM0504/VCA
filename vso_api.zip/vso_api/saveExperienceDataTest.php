<?php
//$con=mysqli_connect('localhost','root','','vivo');
include 'init.php';
// Check connection
if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
  { 
    $json = json_decode(file_get_contents('php://input'),true);
   
    $userid = $json["userid"]; 
    $value = $json["value"]; 
    $name = $json["name"]; 
    $image = $json["image"];
    
    $companyName = $json["companyName"];
    $jobTitle = $json["jobTitle"];
    $startDate = $json["startDate"];
    $endDate = $json["endDate"];
 
    $response = array();
    $check_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' AND `category`='user' limit 1";
    $check_result = $conn->query($check_sql);
    if ($check_result->num_rows > 0) {
        $decodedImage = base64_decode("$image");

        $folder = "/home/otqje8rkxco5/public_html/wp-content/themes/oceanwp/upload/";
        $return = file_put_contents($folder.$name, $decodedImage);
     
        if($return !== false){
            $response['success'] = 1;
            $response['message'] = "Yes";
            $image_link = "http://www.vivorajonbording.com/wp-content/themes/oceanwp/upload/";
            
            if($value=='experience'){
                //$sql = "UPDATE `employee_personal_detail` SET `passport_size_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                $sql = "INSERT INTO `employee_experience_table`(`userid`, `company_name`, `company_job_title`, `company_start_date`, `company_end_date`, `experience_letter`) 
                            	VALUES ('".$userid."','".$companyName."','".$jobTitle."','".$startDate."','".$endDate."', '".$image_link.$name."')";
                mysqli_query($conn, $sql);
            }
        }else{
            $response['success'] = 0;
            $response['message'] = "Image Uploaded Failed";
        }
     
        echo json_encode($response);
    }
    else{
        $response['message'] = "Please add personal details first";
        echo json_encode($response);  
    }
   
  }
?>