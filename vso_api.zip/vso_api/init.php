<?php
    $servername = "localhost";
    $username = "vivoraj1_onboarding";
    $password = "m_G6I#uGE}G2";
    $db_name = "vivoraj1_onboarding";
    
    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $db_name);
    
    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }
    else{
        //echo "Connected successfully";
    }
?>