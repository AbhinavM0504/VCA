<?php 
    include 'init.php';
    
    //set time zone
    date_default_timezone_set("Asia/Calcutta");
     
    //Person details params
    $userid = $_POST['userid'];
    
    $initial = $_POST['initial'];
    $username = $_POST['name'];
    $email = $_POST['email'];
    $number = $_POST['contactNo'];
    $father_name = $_POST['fatherName'];
    $mother_name = $_POST['motherName'];
    //$joining_date = $_POST['joiningDate'];
    $dob = $_POST['dob'];
    $gender = $_POST['genderValue'];
    $blood_group = $_POST['bloodGroupValue'];
    $aadhar_no = $_POST['aadharNo'];
    $pan_no = $_POST['panNo'];
    $marital_status = $_POST['maritalStatusValue'];
    $pin_code = $_POST['pinCode'];
    $permanent_address = $_POST['permanentAddress'];
    $current_address = $_POST['currentAddress'];
    $bank_account_no  = $_POST['bankAccountNo'];
    $bank_ifsc = $_POST['ifscCode'];
    
    $uan_no  = $_POST['uanNo'];
    $esic_no = $_POST['esicNo'];
    
    //work with company params
    $work_choice = $_POST['choiceCd'];
    $work_with_company_department = $_POST['department'];
    $work_with_company_designation = $_POST['designation'];
    $work_with_company_doj = $_POST['doj'];
    $work_with_company_dol = $_POST['dol'];
    
    //company relation params
    $relation_choice = $_POST['choiceCr'];
    $company_relation_name = $_POST['relationName'];
    $company_relation_relation = $_POST['relation'];
    $company_relation_designation = $_POST['relationDesignation'];
    
    //emergency contact person params
    $person_name = $_POST['emergencyName'];
    $person_number = $_POST['emergencyNo'];
    $person_relation = $_POST['emergencyRelation'];
    
    //time
    //$time = date('Y-m-d H:i:s');
    
    
    //checking empty condition for params
    if(isset($userid, $username, $email, $number, $father_name, $dob, $gender, $blood_group, $aadhar_no,$pan_no, $marital_status,
    $pin_code, $permanent_address, $current_address, $bank_account_no, $bank_ifsc, $work_choice, $relation_choice, $person_name, $person_number, $person_relation)){

        $sql = "SELECT * from add_users WHERE `userid` = '".$userid."' limit 1";
        $result = $conn->query($sql);
        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()) {
                $joining_date = "".$row['joining_date']."";
                $designation = "".$row['designation']."";
                $department = "".$row['department']."";
                $grade = "".$row['grade']."";
                $branch = "".$row['branch']."";
                $zone = "".$row['zone']."";
                $employee_level = "".$row['employee_level']."";
                $category = "".$row['category']."";
                $user_status = "".$row['user_status']."";
                $salary = "".$row['salary']."";
                $candidate_category = "".$row['candidate_category']."";
                
                $modified_name = ucwords(strtolower($username));
                
                if(isset($designation, $department, $grade, $branch, $zone, $employee_level, $category, $user_status, $salary, $candidate_category)){
                    
                    //insert data to db
                    $get_data_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
                	$result1 = $conn->query($get_data_sql);
                	if ($result1->num_rows > 0) {
                    	  $update_sql = "Update employee_personal_detail 
                    	            SET
                    	            `initial`= '".$initial."',
                    	            `name`= '".$modified_name."',
                    	            `father_name`= '".$father_name."',
                    	            `mother_name`= '".$mother_name."',
                    	            `joining_date`= '".$joining_date."',
                    	            `dob`= '".$dob."',
                    	            `gender`= '".$gender."',
                    	            `blood_group`= '".$blood_group."',
                    	            `marital_status`= '".$marital_status."',
                    	            `email`= '".$email."',
                        	        `number`= '".$number."',
                        	        `pin_code`= '".$pin_code."',
                        	        `aadhar_no`= '".$aadhar_no."',
                        	        `pan_no`= '".$pan_no."', 
                        	        `uan_no`= '".$uan_no."', 
                        	        `esic_no`= '".$esic_no."',
                        	        `permanent_address`= '".$permanent_address."',
                        	        `current_address`= '".$current_address."',
                        	        `work_with_company`= '".$work_choice."',
                        	        `work_with_company_department`= '".$work_with_company_department."', 
                        	        `work_with_company_designation` = '".$work_with_company_designation."',
                        	        `work_with_company_doj` = '".$work_with_company_doj."',
                        	        `work_with_company_dol` = '".$work_with_company_dol."',
                        	        `company_relation` = '".$relation_choice."',
                        	        `company_relation_name` = '".$company_relation_name."', 
                        	        `company_relation_relation` = '".$company_relation_relation."',
                        	        `company_relation_designation` = '".$company_relation_designation."',
                        	        `bank_account_no` = '".$bank_account_no."',
                        	        `bank_ifsc` = '".$bank_ifsc."',
                        	        `person_name` = '".$person_name."',
                        	        `person_number`= '".$person_number."',
                        	        `person_relation` = '".$person_relation."'
                        	        WHERE `userid`='".$userid."'";
                        	if(mysqli_query($conn, $update_sql))
                        	{
                        		echo 'Data has been updated successfully...';
                        	}
                        	else
                        	{
                        		echo "Unable to update data !!!";
                        	}
                	}
                	else 
                	{   
                	    $time = date('Y-m-d H:i:s');
                        $insert_sql = "INSERT INTO `employee_personal_detail`(`userid`, `initial`, `name`, `father_name`, `mother_name`, `joining_date`, `dob`, `gender`, `blood_group`, `marital_status`, `email`,
                    	`number`, `pin_code`, `aadhar_no`, `pan_no`, `uan_no`, `esic_no`, `permanent_address`, `current_address`, `work_with_company`, `work_with_company_department`, 
                    	`work_with_company_designation`, `work_with_company_doj`, `work_with_company_dol`, `company_relation`, `company_relation_name`, 
                    	`company_relation_relation`, `company_relation_designation`, `bank_account_no`, `bank_ifsc`, `person_name`, `person_number`, `person_relation`, `time`)
                    	VALUES ('".$userid."', '".$initial."', '".$modified_name."','".$father_name."','".$mother_name."','".$joining_date."','".$dob."', '".$gender."','".$blood_group."','".$marital_status."','".$email."',
                    	'".$number."', '".$pin_code."', '".$aadhar_no."','".$pan_no."','".$uan_no."','".$esic_no."','".$permanent_address."','".$current_address."','".$work_choice."','".$work_with_company_department."',
                    	'".$work_with_company_designation."','".$work_with_company_doj."','".$work_with_company_dol."','".$relation_choice."','".$company_relation_name."',
                    	'".$company_relation_relation."','".$company_relation_designation."','".$bank_account_no."','".$bank_ifsc."','".$person_name."','".$person_number."',
                    	'".$person_relation."', '".$time."')";
                            
                    	if(mysqli_query($conn, $insert_sql))
                    	{
                    		echo 'Data has been saved successfully...';
                    	}
                    	else
                    	{
                    		echo "Unable to save data !!!";
                    	}
                    }
                }
                else{
                    echo "Unable to save data !!!";
                }
            	
            }
        }
    }
    else
    {
    	echo "Fields are empty";
    }
    mysqli_close($conn);
?>