<?php 
    include 'init.php';
    
    //set time zone
    date_default_timezone_set("Asia/Calcutta");
    
    /*//Person details params
    $userid = $_POST['userid'];
    $companyName = $_POST['companyName'];
    $jobTitle = $_POST['jobTitle'];
    $startDate = $_POST['startDate'];
    $endDate = $_POST['endDate'];
  
    
    //checking empty condition for params
    if(isset($userid, $companyName, $jobTitle, $startDate, $endDate)){

        //insert data to db
        $insert_sql = "INSERT INTO `employee_experience_table`(`userid`, `company_name`, `company_job_title`, `company_start_date`, `company_end_date`) 
                            	VALUES ('".$userid."','".$companyName."','".$jobTitle."','".$startDate."','".$endDate."')";
            
    	if(mysqli_query($conn, $insert_sql))
    	{
    		echo 'Experience has been saved successfully...';
    	}
    	else
    	{
    		echo "Unable to save experience !!!";
    	}
    }
    else
    {
    	echo "Fields are empty";
    }
    mysqli_close($conn);*/
    
    //$con=mysqli_connect('localhost','root','','vivo');
    // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    else
    { 
        $json = json_decode(file_get_contents('php://input'),true);
       
        $userid = $json["userid"]; 
        $value = $json["value"]; 
        $name = $json["name"]; 
        $image = $json["image"];
        
        $companyName = $json["companyName"];
        $jobTitle = $json["jobTitle"];
        $startDate = $json["startDate"];
        $endDate = $json["endDate"];
        
        $response = array();
        $check_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
        $check_result = $conn->query($check_sql);
        if ($check_result->num_rows > 0) {
            $decodedImage = base64_decode("$image");
    
            // $folder = "/home/otqje8rkxco5/public_html/wp-content/themes/oceanwp/upload/";
            $folder = "../upload/";
            $return = file_put_contents($folder.$name, $decodedImage);
         
            if($return !== false){
                $response['success'] = 1;
                $response['message'] = "Yes";
                // $image_link = "http://www.vivorajonbording.com/wp-content/themes/oceanwp/upload/";
                $image_link = "https://vivorajonbording.com/api/upload/";
                
                if($value=='experience'){
                    $time = date('Y-m-d H:i:s');
                    //$sql = "UPDATE `employee_personal_detail` SET `passport_size_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                    $sql = "INSERT INTO `employee_experience_table`(`userid`, `company_name`, `company_job_title`, `company_start_date`, `company_end_date`, `experience_letter`, `time`) 
                                	VALUES ('".$userid."','".$companyName."','".$jobTitle."','".$startDate."','".$endDate."', '".$image_link.$name."', '".$time."')";
                    mysqli_query($conn, $sql);
                }
            }else{
                $response['success'] = 0;
                $response['message'] = "Image Uploaded Failed";
            }
         
            echo json_encode($response);
        }
        else{
            $response['message'] = "Please add personal details first";
            echo json_encode($response);  
        }
    }
?>