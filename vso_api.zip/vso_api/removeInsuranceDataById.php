<?php
include 'init.php';

$id=$_POST['id'];

if(isset($id)){
	$sql = "DELETE from `employee_insurance_table` WHERE `id`='".$id."'";
	if(mysqli_query($conn,$sql)){
		echo("Insurance removed successfully...");
	}else{
		echo("Unable to remove insurance");
	};	
}
else{
	echo ("Unable to remove insurance");
}
mysqli_close($conn);
 ?>