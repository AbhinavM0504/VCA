<?php
    include 'init.php';

    $userid = $_POST['userid'];
    $category = $_POST['category'];
 
    
    $userData = array();
    
    if(isset($userid, $category)){
    
        //get notification count
        $nCountRow = "";
        $notification_count_sql = "SELECT count(*) as 'notification_count' FROM `employee_notification_table` WHERE `userid` = '".$userid."' AND `notification_status`='Delivered'";
    	$notificationCountResult = $conn->query($notification_count_sql);
    	if ($notificationCountResult->num_rows > 0) {
        	  while($countRow = $notificationCountResult->fetch_assoc()) 
        	  {
        	      $nCountRow = "".$countRow["notification_count"]."";
        	  }
    	}
    	
        $login_sql = "SELECT * FROM `add_users` WHERE `userid` = '".$userid."' AND `category`='user'";
        //$login_sql = "SELECT * FROM `add_users` WHERE `userid` = '".$userid."' AND `category`='user' UNION ALL Select count(*) from notification_table where `userid` = '".$userid."' AND `notification_status` = 'Delivered'";
    	$result = $conn->query($login_sql);
    	
    	
    	if ($result->num_rows > 0) {
        	  while($row = $result->fetch_assoc()) 
        	  {
        	      $temp = [
            		 'id'=>"".$row["id"]."",
            		 'userid'=>"".$row["userid"]."",
            		 'password'=>"".$row["password"]."",
            		 'designation'=>"".$row["designation"]."",
            		 'department'=>"".$row["department"]."",
            		 'grade'=>"".$row["grade"]."",
            		 'branch'=>"".$row["branch"]."",
            		 'zone'=>"".$row["zone"]."",
            		 'employee_level'=>"".$row["employee_level"]."",
            		 'category'=>"".$row["category"]."",
            		 'user_status'=>"".$row["user_status"]."",
            		 'salary'=>"".$row["salary"]."",
            		 'create_at'=>"".$row["create_at"]."",
            		 'update_at'=>"".$row["update_at"]."",
            		 'candidate_category'=>"".$row["candidate_category"]."",
            		 'app_version'=>"".$row["app_version"]."",
            		 'image'=>"".$row["image"]."",
            		 'notification_count'=>$nCountRow
            		 ];
		 
        		  array_push($userData, $temp);
        		  
    		      echo json_encode($userData);
        	  }
    	}
    	else {
            echo "Please check your details..!!";
        }
    }
    else {
        echo "Please check your details..!!";
    }   
    mysqli_close($conn);
?>