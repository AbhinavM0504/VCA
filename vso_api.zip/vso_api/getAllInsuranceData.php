<?php
    include 'init.php';

    $userid = $_POST['userid'];
    
    $insuranceData = array();
    $response = array();
    
    if(isset($userid)){
        
        
        //check request
        $check_request_sql = "SELECT * from employee_personal_detail WHERE userid = '".$userid."'";
        $check_request_result = $conn->query($check_request_sql);
        if($check_request_result->num_rows > 0){
            while($check_row = $check_request_result->fetch_assoc()) 
        	{
        	    $response['request'] = $check_row['request'];
        	    $response['member_included_for_insurance'] = $check_row['member_included_for_insurance'];
        	}
        }
        else{
    	    $response['request'] = '';
    	    $response['member_included_for_insurance'] = '';
        }
        
        //get request
        $get_experience_sql = "SELECT 
                                t1.id as id, 
                                t1.userid as userid, 
                                t1.member_relation as member_relation, 
                                t1.member_name as member_name, 
                                t1.member_dob as member_dob, 
                                t1.member_ac_front_image as member_ac_front_image, 
                                t1.member_ac_back_image as member_ac_back_image, 
                                t2.request as request, 
                                t1.time as time
        FROM `employee_insurance_table` as t1, employee_personal_detail as t2 WHERE t1.userid = t2.userid AND t1.userid = '".$userid."' order by t1.id desc";
    	$result = $conn->query($get_experience_sql);
    	
    	if ($result->num_rows > 0) {
        	  while($row = $result->fetch_assoc()) 
        	  {
        	  
        	      $temp = [
            		 'id'=>"".$row["id"]."",
            		 'userid'=>"".$row["userid"]."",
            		 'member_relation'=>"".$row["member_relation"]."",
            		 'member_name'=>"".$row["member_name"]."",
            		 'member_dob'=>"".$row["member_dob"]."",
            		 'member_ac_front_image'=>"".$row["member_ac_front_image"]."",
            		 'member_ac_back_image'=>"".$row["member_ac_back_image"]."",
            		 'request'=>"".$row["request"]."",
            		 'time'=>"".$row["time"].""
            		 ];
		 
        		  array_push($insuranceData, $temp);
        	  }
        	  $response['status'] = true;
        	  $response['message'] = $insuranceData;
    	}
    	else {
            $response['status'] = false;
    	    $response['message'] = "No data available";
        }
    }
    else {
        $response['status'] = false;
	    $response['message'] = "Invalid user";
    }   
    echo json_encode($response);
    
    mysqli_close($conn);
?>