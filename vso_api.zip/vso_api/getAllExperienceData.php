<?php
    include 'init.php';

    $userid = $_POST['userid'];
    
    $experienceData = array();
    $response = array();
    
    if(isset($userid)){
        
        //get request
    	$request = "";
    	$ho_request = "";
    	/*$get_status_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
    	
    	$result_status = $conn->query($get_status_sql);
    	if($result_status->num_rows > 0){
    	    while($row_status = $result_status->fetch_assoc())
        	  {
        	    $request="".$row_status["request"]."";
        	    $ho_request="".$row_status["ho_request"]."";
        	      
        	  }
    	}*/
    	
    	
        //$get_experience_sql = "SELECT * FROM `employee_experience_table` WHERE `userid` = '".$userid."' order by id desc";
        $get_experience_sql = "SELECT 
                                t1.id as id, 
                                t1.userid as userid, 
                                t1.company_name as company_name, 
                                t1.company_job_title as company_job_title, 
                                t1.company_start_date as company_start_date, 
                                t1.company_end_date as company_end_date, 
                                t1.experience_letter as experience_letter, 
                                t1.time as time, 
                                t2.request as request,
                                t2.ho_request as ho_request
        FROM `employee_experience_table` as t1, employee_personal_detail as t2 WHERE t1.userid = t2.userid AND t1.userid = '".$userid."' order by t1.id desc";
    	$result = $conn->query($get_experience_sql);
    	
    	if ($result->num_rows > 0) {
        	  while($row = $result->fetch_assoc()) 
        	  {
        	  
        	      $temp = [
            		 'id'=>"".$row["id"]."",
            		 'userid'=>"".$row["userid"]."",
            		 'company_name'=>"".$row["company_name"]."",
            		 'company_job_title'=>"".$row["company_job_title"]."",
            		 'company_start_date'=>"".$row["company_start_date"]."",
            		 'company_end_date'=>"".$row["company_end_date"]."",
            		 'experience_letter'=>"".$row["experience_letter"]."",
            		 'time'=>"".$row["time"]."",
            		 'request'=>"".$row["request"]."",
            		 'ho_request'=>"".$row["ho_request"].""
            		 ];
		 
        		  array_push($experienceData, $temp);
        	  }
        	  $response['status'] = true;
        	  $response['message'] = $experienceData;
        	  
        	  //echo json_encode($experienceData);
    	}
    	else {
            $response['status'] = false;
    	    $response['message'] = "No data available";
        }
    }
    else {
        $response['status'] = false;
	    $response['message'] = "Invalid user";
    }   
    echo json_encode($response);
    
    mysqli_close($conn);
?>