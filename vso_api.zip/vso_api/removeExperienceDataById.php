<?php
include 'init.php';

$id=$_POST['id'];

if(isset($id)){
	$sql = "DELETE from `employee_experience_table` WHERE `id`='".$id."'";
	if(mysqli_query($conn,$sql)){
		echo("Experience removed successfully...");
	}else{
		echo("Unable to remove experience");
	};	
}
else{
	echo ("Unable to remove experience");
}
mysqli_close($conn);
 ?>