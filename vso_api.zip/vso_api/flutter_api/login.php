<?php
    include '../init.php';

    $username = 'rishi96';//$_POST['username'];
    $password = '123456';//$_POST['password'];
    
    $logindata = array();
    $response = array();
    
    if(isset($username, $password)){
        $login_sql = "SELECT * FROM `add_users` WHERE `userid` = '".$username."' AND `password` = '".$password."' AND `user_status`='Activated' AND `category`='user'";
    	$result = $conn->query($login_sql);
    	
    	
    	if ($result->num_rows > 0) {
        	  while($row = $result->fetch_assoc()) 
        	  {
        	      $update_sql = "UPDATE add_users SET app_version = '".$appVersion."' where `userid` = '".$username."' AND `password` = '".$password."'";
        	      $result1 = $conn->query($update_sql);
        	      
        	      $temp = [
            		 'id'=>"".$row["id"]."",
            		 'userid'=>"".$row["userid"]."",
            		 'password'=>"".$row["password"]."",
            		 'designation'=>"".$row["designation"]."",
            		 'department'=>"".$row["department"]."",
            		 'grade'=>"".$row["grade"]."",
            		 'branch'=>"".$row["branch"]."",
            		 'zone'=>"".$row["zone"]."",
            		 'employee_level'=>"".$row["employee_level"]."",
            		 'category'=>"".$row["category"]."",
            		 'user_status'=>"".$row["user_status"]."",
            		 'salary'=>"".$row["salary"]."",
            		 'create_at'=>"".$row["create_at"]."",
            		 'update_at'=>"".$row["update_at"]."",
            		 'candidate_category'=>"".$row["candidate_category"]."",
            		 'app_version'=>"".$row["app_version"]."",
            		 'image'=>"".$row["image"].""
            		 ];
		 
        		  array_push($logindata, $temp);
        	  }
        	  
        	  $response['status'] = true;
            $response['message'] = $logindata;
    	}
    	else {
            echo "Please check your details..!!";
        }
    }
    else {
        $response['status'] = false;
        $response['message'] = "Please check your details..!!";
    }   
    
     echo json_encode($response);
    mysqli_close($conn);
?>