<?php
    include 'init.php';

    $userid = $_POST['userid'];
    
    $qualificationData = array();
    
    if(isset($userid)){
        $get_qualification_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
        //$get_qualification_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' AND `category`='user' limit 1";
    	$result = $conn->query($get_qualification_sql);
    	
    	
    	if ($result->num_rows > 0) {
        	  while($row = $result->fetch_assoc()) 
        	  {
        	      $temp = [
            		 'id'=>"".$row["id"]."",
            		 'userid'=>"".$row["userid"]."",
            		 '10_school'=>"".$row["10_school"]."",
            		 '10_board'=>"".$row["10_board"]."",
            		 '10_percentage'=>"".$row["10_percentage"]."",
            		 '10_year_passing'=>"".$row["10_year_passing"]."",
            		 '10_image'=>"".$row["10_image"]."",
            		 '12_choice'=>"".$row["12_choice"]."",
            		 '12_school'=>"".$row["12_school"]."",
            		 '12_board'=>"".$row["12_board"]."",
            		 '12_percentage'=>"".$row["12_percentage"]."",
            		 '12_year_passing'=>"".$row["12_year_passing"]."",
            		 '12_image'=>"".$row["12_image"]."",
            		 'graduation_choice'=>"".$row["graduation_choice"]."",
            		 'graduation_course'=>"".$row["graduation_course"]."",
            		 'graduation_university'=>"".$row["graduation_university"]."",
            		 'graduation_board'=>"".$row["graduation_board"]."",
            		 'graduation_percentage'=>"".$row["graduation_percentage"]."",
            		 'graduation_year_passing'=>"".$row["graduation_year_passing"]."",
            		 'graduation_image'=>"".$row["graduation_image"]."",
            		 'post_graduation_choice'=>"".$row["post_graduation_choice"]."",
            		 'post_graduation_course'=>"".$row["post_graduation_course"]."",
            		 'post_graduation_university'=>"".$row["post_graduation_university"]."",
            		 'post_graduation_board'=>"".$row["post_graduation_board"]."",
            		 'post_graduation_percentage'=>"".$row["post_graduation_percentage"]."",
            		 'post_graduation_year_passing'=>"".$row["post_graduation_year_passing"]."",
            		 'post_graduation_image'=>"".$row["post_graduation_image"]."",
            		 'other_qualification_choice'=>"".$row["other_qualification_choice"]."",
            		 'other_qualification_course'=>"".$row["other_qualification_course"]."",
            		 'other_qualification_university'=>"".$row["other_qualification_university"]."",
            		 'other_qualification_board'=>"".$row["other_qualification_board"]."",
            		 'other_qualification_percentage'=>"".$row["other_qualification_percentage"]."",
            		 'other_qualification_year_passing'=>"".$row["other_qualification_year_passing"]."",
            		 'other_qualification_image'=>"".$row["other_qualification_image"]."",
            		 'request'=>"".$row["request"]."",
            		 'ho_request'=>"".$row["ho_request"].""
            		 ];
		 
        		  array_push($qualificationData, $temp);
        		  
    		      echo json_encode($qualificationData);
        	  }
    	}
    	else {
            echo "Please check your details..!!";
        }
    }
    else {
        echo "Please check your details..!!";
    }   
    mysqli_close($conn);
?>