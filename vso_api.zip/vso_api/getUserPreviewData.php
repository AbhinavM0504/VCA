<?php
    include 'init.php';

    $userid = $_POST['userid'];
    
    $previewData = array();
    
    if(isset($userid)){
        $get_preview_sql = "SELECT * FROM `employee_personal_detail` as t1, add_users as t2 WHERE t1.userid = t2.userid AND t1.userid = '".$userid."' limit 1";
    	$result = $conn->query($get_preview_sql);
    	
    	//get last company entry
    	$company_name = "";
        $company_job_title = "";
        $company_start_date = "";
        $company_end_date = "";
    	//$get_exp_sql = "SELECT * FROM employee_experience_table WHERE userid = '".$userid."' order by id desc limit 1";
    	$get_exp_sql = "SELECT * FROM `employee_experience_table` WHERE company_end_date = (select DATE_FORMAT(MAX(STR_TO_DATE(company_end_date,'%d/%m/%Y')), '%d/%m/%Y') as DateFormat from employee_experience_table where userid = '".$userid."')";
    	$result_exp = $conn->query($get_exp_sql);
    	if($result_exp->num_rows > 0){
    	    while($row_exp = $result_exp->fetch_assoc()) 
        	  {
        	    $company_name="".$row_exp["company_name"]."";
        	    $company_job_title="".$row_exp["company_job_title"]."";
        	    $company_start_date="".$row_exp["company_start_date"]."";
        	    $company_end_date="".$row_exp["company_end_date"]."";
        	      
        	  }
    	}
    	
    	$hr_sign_image = "";
    	$head_hr_sign = "";
    	$head_hr_sign_name = "";
    	$cmp_name = "";
    	$cmp_address = "";
    	$cmp_email = "";
    	
    	if ($result->num_rows > 0) {
        	  while($row = $result->fetch_assoc()) 
        	  {
        	      
        	      if($row["request"] == 'Approved'){
        	          $hr_sign_image = $row['zhr_image'];
        	      }
        	      
        	      if($row["ho_request"] == 'Approved'){
        	          $head_hr_sign = $row['head_hr_image'];
        	      }
        	      
        	      
        	      
        	      if($row["zone"] == 'JTPL'){
        	          $head_hr_sign_name = "Manoj Bhatt";
        	          $cmp_name = "Jeevan Telecommunication Private Limited";
        	          $cmp_address = "Shekhawat Complex - 1st Floor, Parivahan Nagar, Above ICICI &  SBI Bank, Khatipura, Jaipur (302012), Rajasthan";
        	          $cmp_email = "";
        	      }
        	      else{
        	          $head_hr_sign_name = "Rajesh Kumar Sharma";
        	          $cmp_name = "Bubugao Communication Private Limited";
        	          $cmp_address = "Torus 340, Metro Pillar no. 93, Near Sanjeevni Hospital, New Sanganer road, Jaipur ( Rajasthan)- 302019";
        	          $cmp_email = "";
        	      }
        	      
        	      $temp = [
            		 'id'=>"".$row["id"]."",
            		 'userid'=>"".$row["userid"]."",
            		 'department'=>"".$row["department"]."",
            		 'designation'=>"".$row["designation"]."",
            		 'grade'=>"".$row["grade"]."",
            		 'branch'=>"".$row["branch"]."",
            		 'zone'=>"".$row["zone"]."",
            		 'company_name'=>$cmp_name,
            		 'company_address'=>$cmp_address,
            		 'company_email'=>$cmp_email,
            		 'employee_level'=>"".$row["employee_level"]."",
            		 'category'=>"".$row["category"]."",
            		 'user_status'=>"".$row["user_status"]."",
            		 'salary'=>"".$row["salary"]."",
            		 'candidate_category'=>"".$row["candidate_category"]."",
            		 'name'=>"".$row["initial"].""."".$row["name"]."",
            		 'father_name'=>"".$row["father_name"]."",
            		 'joining_date'=>"".$row["joining_date"]."",
            		 'dob'=>"".$row["dob"]."",
            		 'gender'=>"".$row["gender"]."",
            		 'blood_group'=>"".$row["blood_group"]."",
            		 'marital_status'=>"".$row["marital_status"]."",
            		 'email'=>"".$row["email"]."",
            		 'number'=>"".$row["number"]."",
            		 'pin_code'=>"".$row["pin_code"]."",
            		 'aadhar_no'=>"".$row["aadhar_no"]."",
            		 'pan_no'=>"".$row["pan_no"]."",
            		 'uan_no'=>"".$row["uan_no"]."",
            		 'esic_no'=>"".$row["esic_no"]."",
            		 'permanent_address'=>"".$row["permanent_address"]."",
            		 'current_address'=>"".$row["current_address"]."",
            		 'bank_account_no'=>"".$row["bank_account_no"]."",
            		 'bank_ifsc'=>"".$row["bank_ifsc"]."",
            		 'person_name'=>"".$row["person_name"]."",
            		 'person_number'=>"".$row["person_number"]."",
            		 'person_relation'=>"".$row["person_relation"]."",
            		 'passport_size_image'=>"".$row["passport_size_image"]."",
            		 'employee_sign_image'=>"".$row["employee_sign_image"]."",
            		 'aadhar_card_image'=>"".$row["aadhar_card_image"]."",
            		 'aadhar_card_back_image'=>"".$row["aadhar_card_back_image"]."",
            		 'pan_card_image'=>"".$row["pan_card_image"]."",
            		 'last_company_exp_letter_image'=>"".$row["last_company_exp_letter_image"]."",
            		 'pay_slip_exp_letter_image'=>"".$row["pay_slip_exp_letter_image"]."",
            		 'pay_slip_second_last_month_image'=>"".$row["pay_slip_second_last_month_image"]."",
            		 'pay_slip_third_last_month_image'=>"".$row["pay_slip_third_last_month_image"]."",
            		 'resign_mail_image'=>"".$row["resign_mail_image"]."",
            		 'bank_stmt_last_3_mth_image'=>"".$row["bank_stmt_last_3_mth_image"]."",
            		 'offer_letter_image'=>"".$row["offer_letter_image"]."",
            		 //'appointment_letter_image'=>"".$row["appointment_letter_image"]."",
            		 'bank_proof_image'=>"".$row["bank_proof_image"]."",
            		 'vaccine_certificate_image'=>"".$row["vaccine_certificate_image"]."",
            		 'other_documents_pdf'=>"".$row["other_documents_pdf"]."",
            		 'father_n_name'=>"".$row["father_n_name"]."",
            		 'father_relation'=>"".$row["father_relation"]."",
            		 'father_dob'=>"".$row["father_dob"]."",
            		 'father_amount'=>"".$row["father_amount"]."",
            		 'mother_n_name'=>"".$row["mother_n_name"]."",
            		 'mother_relation'=>"".$row["mother_relation"]."",
            		 'mother_dob'=>"".$row["mother_dob"]."",
            		 'mother_amount'=>"".$row["mother_amount"]."",
            		 'wife_n_name'=>"".$row["wife_n_name"]."",
            		 'wife_relation'=>"".$row["wife_relation"]."",
            		 'wife_dob'=>"".$row["wife_dob"]."",
            		 'wife_amount'=>"".$row["wife_amount"]."",
            		 'guardian_n_name'=>"".$row["guardian_name"]."",
            		 'guardian_relation'=>"".$row["guardian_relation"]."",
            		 'guardian_dob'=>"".$row["guardian_dob"]."",
            		 'guardian_amount'=>"".$row["guardian_amount"]."",
            		 'sibling_n_name'=>"".$row["sibling_name"]."",
            		 'sibling_relation'=>"".$row["sibling_relation"]."",
            		 'sibling_dob'=>"".$row["sibling_dob"]."",
            		 'sibling_amount'=>"".$row["sibling_amount"]."",
            		 'child_one_name'=>"".$row["child_one_name"]."",
            		 'child_one_relation'=>"".$row["child_one_relation"]."",
            		 'child_one_dob'=>"".$row["child_one_dob"]."",
            		 'child_one_amount'=>"".$row["child_one_amount"]."",
            		 'child_two_name'=>"".$row["child_two_name"]."",
            		 'child_two_relation'=>"".$row["child_two_relation"]."",
            		 'child_two_dob'=>"".$row["child_two_dob"]."",
            		 'child_two_amount'=>"".$row["child_two_amount"]."",
            		 'last_company_name'=>$company_name,
            		 'last_company_job'=>$company_job_title,
            		 'last_company_doj'=>$company_start_date,
            		 'last_company_dol'=>$company_end_date,
            		 'request'=>"".$row["request"]."",
            		 'ho_request'=>"".$row["ho_request"]."",
            		 'employee_id'=>"".$row["employee_id"]."",
            		 'v_work_code'=>"".$row["v_work_code"]."",
            		 'hr_sign_image'=>"".$hr_sign_image."",
            		 'head_hr_sign_image'=>$head_hr_sign,
            		 'head_hr_sign_name'=>$head_hr_sign_name,
            		 'image_10'=>"".$row["10_image"]."",
            		 'image_12'=>"".$row["12_image"]."",
            		 'image_g'=>"".$row["graduation_image"]."",
            		 'image_pg'=>"".$row["post_graduation_image"]."",
            		 'image_other'=>"".$row["other_qualification_image"].""
            		 ];
		 
        		  array_push($previewData, $temp);
        		  
    		      echo json_encode($previewData);
        	  }
    	}
    	else {
            echo "Please check your details..!!";
        }
    }
    else {
        echo "Please check your details..!!";
    }   
    mysqli_close($conn);
?>