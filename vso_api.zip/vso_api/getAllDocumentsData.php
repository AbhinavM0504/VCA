<?php
    include 'init.php';

    $userid = $_POST['userid'];
    
    $documentData = array();
    
    if(isset($userid)){
        $get_document_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
    	$result = $conn->query($get_document_sql);
    	
    	
    	if ($result->num_rows > 0) {
        	  while($row = $result->fetch_assoc()) 
        	  {
        	      $temp = [
            		 'id'=>"".$row["id"]."",
            		 'userid'=>"".$row["userid"]."",
            		 'passport_size_image'=>"".$row["passport_size_image"]."",
            		 'employee_sign_image'=>"".$row["employee_sign_image"]."",
            		 'aadhar_card_image'=>"".$row["aadhar_card_image"]."",
            		 'aadhar_card_back_image'=>"".$row["aadhar_card_back_image"]."",
            		 'pan_card_image'=>"".$row["pan_card_image"]."",
            		 'bank_proof_image'=>"".$row["bank_proof_image"]."",
            		 'last_company_exp_letter_image'=>"".$row["last_company_exp_letter_image"]."",
            		 'pay_slip_exp_letter_image'=>"".$row["pay_slip_exp_letter_image"]."",
            		 'pay_slip_second_last_month_image'=>"".$row["pay_slip_second_last_month_image"]."",
            		 'pay_slip_third_last_month_image'=>"".$row["pay_slip_third_last_month_image"]."",
            		 'resign_mail_image'=>"".$row["resign_mail_image"]."",
            		 'bank_stmt_last_3_mth_image'=>"".$row["bank_stmt_last_3_mth_image"]."",
            		 'offer_letter_image'=>"".$row["offer_letter_image"]."",
            		 'vaccine_certificate_image'=>"".$row["vaccine_certificate_image"]."",
            		 'other_documents_pdf'=>"".$row["other_documents_pdf"]."",
            		 'request'=>"".$row["request"]."",
            		 'ho_request'=>"".$row["ho_request"].""
            		 ];
		 
        		  array_push($documentData, $temp);
        		  
    		      echo json_encode($documentData);
        	  }
    	}
    	else {
            echo "Please check your details..!!";
        }
    }
    else {
        echo "Please check your details..!!";
    }   
    mysqli_close($conn);
?>