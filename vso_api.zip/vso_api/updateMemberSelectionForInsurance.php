<?php 
    include 'init.php';
    
    //set time zone
    date_default_timezone_set("Asia/Calcutta");
    
    //PARAMS
    $userid = $_POST['userid'];
    $insurance_choice = $_POST['insurance_choice'];
  
    //arrays
    $response = array();
    
    if(isset($userid, $insurance_choice)){

        //update insurance_choice to db
        $update_ins_choice_sql = "UPDATE `employee_personal_detail` SET `member_included_for_insurance`='".$insurance_choice."' WHERE `userid` = '".$userid."'";
    	if(mysqli_query($conn, $update_ins_choice_sql))
    	{
    	    if($insurance_choice == 'No'){
    	        $remove_member_sql = "DELETE FROM `employee_insurance_table` WHERE `userid` = '".$userid."'";
    	        if(mysqli_query($conn, $remove_member_sql)){
    	            $response['status'] = true;
            	    $response['message'] = "Member Adding Policy Disabled..";
            	    $response['choice'] = "No";
    	        }
    	    }
    	    else{
    	        $response['status'] = true;
        	    $response['message'] = "Member Adding Policy Enabled..";
    	        $response['choice'] = "Yes";
    	    } 
    	}
    	else
    	{
    		$response['status'] = false;
    	    $response['message'] = "Unable to update Member Adding Policy..";
    	    $response['choice'] = "";
    	}
    }
    else
    {
    	$response['status'] = false;
	    $response['message'] = "Unable to update Member Adding Policyyyyyyyyyy..";
	    $response['choice'] = "";
    }
    echo json_encode($response);
    mysqli_close($conn);
?>