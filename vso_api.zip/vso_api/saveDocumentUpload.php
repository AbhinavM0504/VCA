<?php
//$con=mysqli_connect('localhost','root','','vivo');
include 'init.php';
// Check connection
if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
  { 
    $json = json_decode(file_get_contents('php://input'),true);
   
    $userid = $json["userid"]; 
    $value = $json["value"]; 
    $name = $json["name"]; 
    $image = $json["image"];
 
    $response = array();
    $check_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
    $check_result = $conn->query($check_sql);
    if ($check_result->num_rows > 0) {
        $decodedImage = base64_decode("$image");

        // $folder = "/home/otqje8rkxco5/public_html/wp-content/themes/oceanwp/upload/";
        $folder = "../upload/";
        $return = file_put_contents($folder.$name, $decodedImage);
     
        if($return !== false){
            $response['success'] = 1;
            $response['message'] = "Yes";
            //$image_link = "http://www.vivorajonbording.com/wp-content/themes/oceanwp/upload/";
            $image_link = "https://vivorajonbording.com/api/upload/";
            
            if($value=='passport'){
                $sql = "UPDATE `employee_personal_detail` SET `passport_size_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='emp_sign'){
                $sql = "UPDATE `employee_personal_detail` SET `employee_sign_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='aadhar_card'){
                $sql = "UPDATE `employee_personal_detail` SET `aadhar_card_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='aadhar_card_back'){
                $sql = "UPDATE `employee_personal_detail` SET `aadhar_card_back_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='pan_card'){
                $sql = "UPDATE `employee_personal_detail` SET `pan_card_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='bank_proof'){
                $sql = "UPDATE `employee_personal_detail` SET `bank_proof_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='cmp_last_exp'){
                $sql = "UPDATE `employee_personal_detail` SET `last_company_exp_letter_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='pay_slip'){
                $sql = "UPDATE `employee_personal_detail` SET `pay_slip_exp_letter_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='pay_slip_second_last_month'){
                $sql = "UPDATE `employee_personal_detail` SET `pay_slip_second_last_month_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='pay_slip_third_last_month'){
                $sql = "UPDATE `employee_personal_detail` SET `pay_slip_third_last_month_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='resign_mail'){
                $sql = "UPDATE `employee_personal_detail` SET `resign_mail_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='bank_stmt'){
                $sql = "UPDATE `employee_personal_detail` SET `bank_stmt_last_3_mth_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='offer_letter'){
                $sql = "UPDATE `employee_personal_detail` SET `offer_letter_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='vaccine_certificate'){
                $sql = "UPDATE `employee_personal_detail` SET `vaccine_certificate_image`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
            if($value=='other_documents'){
                $sql = "UPDATE `employee_personal_detail` SET `other_documents_pdf`='".$image_link.$name."' WHERE `userid`='".$userid."'";
                mysqli_query($conn, $sql);
            }
        }else{
            $response['success'] = 0;
            $response['message'] = "Image Uploaded Failed";
        }
     
        echo json_encode($response);
    }
    else{
        $response['message'] = "Please add personal details first";
        echo json_encode($response);  
    }
   
  }
?>