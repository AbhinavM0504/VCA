<?php
    include 'init.php';

    $userid = $_POST['userid'];

    $userData = array();
    
    if(isset($userid)){
        $get_data_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."'";
    	$result = $conn->query($get_data_sql);
    	
    	if ($result->num_rows > 0) {
        	  while($row = $result->fetch_assoc()) 
        	  {
        	      $temp = [
            		 'id'=>"".$row["id"]."",
            		 'userid'=>"".$row["userid"]."",
            		 'initial'=>"".$row["initial"]."",
            		 'name'=>"".$row["name"]."",
            		 'email'=>"".$row["email"]."",
            		 'number'=>"".$row["number"]."",
            		 'father_name'=>"".$row["father_name"]."",
            		 'mother_name'=>"".$row["mother_name"]."",
            		 'joining_date'=>"".$row["joining_date"]."",
            		 'dob'=>"".$row["dob"]."",
            		 'gender'=>"".$row["gender"]."",
            		 'blood_group'=>"".$row["blood_group"]."",
            		 'aadhar_no'=>"".$row["aadhar_no"]."",
            		 'pan_no'=>"".$row["pan_no"]."",
            		 'marital_status'=>"".$row["marital_status"]."",
            		 'pin_code'=>"".$row["pin_code"]."",
            		 'permanent_address'=>"".$row["permanent_address"]."",
            		 'current_address'=>"".$row["current_address"]."",
            		 'bank_account_no'=>"".$row["bank_account_no"]."",
            		 'bank_ifsc'=>"".$row["bank_ifsc"]."",
            		 'uan_no'=>"".$row["uan_no"]."",
            		 'esic_no'=>"".$row["esic_no"]."",
            		 'work_with_company'=>"".$row["work_with_company"]."",
            		 'work_with_company_department'=>"".$row["work_with_company_department"]."",
            		 'work_with_company_designation'=>"".$row["work_with_company_designation"]."",
            		 'work_with_company_doj'=>"".$row["work_with_company_doj"]."",
            		 'work_with_company_dol'=>"".$row["work_with_company_dol"]."",
            		 'company_relation'=>"".$row["company_relation"]."",
            		 'company_relation_name'=>"".$row["company_relation_name"]."",
            		 'company_relation_relation'=>"".$row["company_relation_relation"]."",
            		 'company_relation_designation'=>"".$row["company_relation_designation"]."",
            		 'person_name'=>"".$row["person_name"]."",
            		 'person_number'=>"".$row["person_number"]."",
            		 'person_relation'=>"".$row["person_relation"]."",
            		 'request'=>"".$row["request"]."",
            		 'ho_request'=>"".$row["ho_request"].""
            		 ];
		 
        		  array_push($userData, $temp);
        		  
    		      echo json_encode($userData);
        	  }
    	}
    	else {
            //echo "Please check your details..!!";
        
    	    $get_data_sql1 = "SELECT * FROM `add_users` WHERE `userid` = '".$userid."'";
    	    $result1 = $conn->query($get_data_sql1);
    	
    	    if ($result1->num_rows > 0) {
        	  while($row1 = $result1->fetch_assoc()) 
        	  {
        	      $temp = [
            		 'id'=>"",
            		 'userid'=>"",
            		 'initial'=>"",
            		 'name'=>"",
            		 'email'=>"",
            		 'number'=>"",
            		 'father_name'=>"",
            		 'mother_name'=>"",
            		 'joining_date'=>"".$row1["joining_date"]."",
            		 'dob'=>"",
            		 'gender'=>"",
            		 'blood_group'=>"",
            		 'aadhar_no'=>"",
            		 'pan_no'=>"",
            		 'marital_status'=>"",
            		 'pin_code'=>"",
            		 'permanent_address'=>"",
            		 'current_address'=>"",
            		 'bank_account_no'=>"",
            		 'bank_ifsc'=>"",
            		 'uan_no'=>"",
            		 'esic_no'=>"",
            		 'work_with_company'=>"",
            		 'work_with_company_department'=>"",
            		 'work_with_company_designation'=>"",
            		 'work_with_company_doj'=>"",
            		 'work_with_company_dol'=>"",
            		 'company_relation'=>"",
            		 'company_relation_name'=>"",
            		 'company_relation_relation'=>"",
            		 'company_relation_designation'=>"",
            		 'person_name'=>"",
            		 'person_number'=>"",
            		 'person_relation'=>"",
            		 'request'=>"",
            		 'ho_request'=>""
            		 ];
		 
        		  array_push($userData, $temp);
        		  
    		      echo json_encode($userData);
        	  }
    	}
    	}
    }
    else {
        echo "Please check your details..!!";
    }   
    mysqli_close($conn);
?>