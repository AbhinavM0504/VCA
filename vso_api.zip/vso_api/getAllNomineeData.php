<?php
    include 'init.php';

    $userid = $_POST['userid'];
    
    $nomineeData = array();
    
    if(isset($userid)){
        $get_nominee_sql = "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
    	$result = $conn->query($get_nominee_sql);
    	
    	
    	if ($result->num_rows > 0) {
        	  while($row = $result->fetch_assoc()) 
        	  {
        	      
        	      $temp = [
            		 'id'=>"".$row["id"]."",
            		 'userid'=>"".$row["userid"]."",
            		 'father_relation'=>"".$row["father_relation"]."",
            		 'father_n_name'=>"".$row["father_n_name"]."",
            		 'father_dob'=>"".$row["father_dob"]."",
            		 'father_amount'=>"".$row["father_amount"]."",
            		 'mother_relation'=>"".$row["mother_relation"]."",
            		 'mother_n_name'=>"".$row["mother_n_name"]."",
            		 'mother_dob'=>"".$row["mother_dob"]."",
            		 'mother_amount'=>"".$row["mother_amount"]."",
            		 'wife_relation'=>"".$row["wife_relation"]."",
            		 'wife_n_name'=>"".$row["wife_n_name"]."",
            		 'wife_dob'=>"".$row["wife_dob"]."",
            		 'wife_amount'=>"".$row["wife_amount"]."",
            		 'guardian_relation'=>"".$row["guardian_relation"]."",
            		 'guardian_name'=>"".$row["guardian_name"]."",
            		 'guardian_dob'=>"".$row["guardian_dob"]."",
            		 'guardian_amount'=>"".$row["guardian_amount"]."",
            		 'sibling_relation'=>"".$row["sibling_relation"]."",
            		 'sibling_name'=>"".$row["sibling_name"]."",
            		 'sibling_dob'=>"".$row["sibling_dob"]."",
            		 'sibling_amount'=>"".$row["sibling_amount"]."",
            		 'child_one_relation'=>"".$row["child_one_relation"]."",
            		 'child_one_name'=>"".$row["child_one_name"]."",
            		 'child_one_dob'=>"".$row["child_one_dob"]."",
            		 'child_one_amount'=>"".$row["child_one_amount"]."",
            		 'child_two_relation'=>"".$row["child_two_relation"]."",
            		 'child_two_name'=>"".$row["child_two_name"]."",
            		 'child_two_dob'=>"".$row["child_two_dob"]."",
            		 'child_two_amount'=>"".$row["child_two_amount"]."",
            		 'request'=>"".$row["request"]."",
            		 'ho_request'=>"".$row["ho_request"].""
            		 ];
		 
        		  array_push($nomineeData, $temp);
        		  
    		      echo json_encode($nomineeData);
        	  }
    	}
    	else {
            echo "Please check your details..!!";
        }
    }
    else {
        echo "Please check your details..!!";
    }   
    mysqli_close($conn);
?>