<?php
    if($_SERVER['REQUEST_METHOD']=='POST'){
      	// echo $_SERVER["DOCUMENT_ROOT"];  // /home1/demonuts/public_html
    	//including the database connection file
      	include_once("init.php");
      	  	
      	//$_FILES['image']['name']   give original name from parameter where 'image' == parametername eg. city.jpg
      	//$_FILES['image']['tmp_name']  temporary system generated name
      
        $userid = $_POST["userid"]; 
        $value = $_POST["value"]; 
        $originalImgName= $_FILES['filename']['name'];
        $tempName= $_FILES['filename']['tmp_name'];
        //$folder="/home/otqje8rkxco5/public_html/wp-content/themes/oceanwp/upload/";
        $folder="../upload/";
        $url = "https://vivorajonbording.com/api/upload/".$originalImgName; //update path as per your directory structure 
    
        if(move_uploaded_file($tempName,$folder.$originalImgName))
        {
        	if($value=='passport'){
                $query = "UPDATE `employee_personal_detail` SET `passport_size_image`='".$url."' WHERE `userid`='".$userid."'";
                if(mysqli_query($conn,$query))
                {
                    $query= "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
                    $result= mysqli_query($conn, $query);
                    $emparray = array();
                    if(mysqli_num_rows($result) > 0){  
                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            $emparray[] = $row;
                        }
                        echo json_encode(array( "status" => "true","message" => "Successfully file added!" , "data" => $emparray) );
                    }
                    else
                    {
                 		echo json_encode(array( "status" => "false","message" => "Failed!") );
                    }
    		   
                }
                else{
                	echo json_encode(array( "status" => "false","message" => "Failed!") );
                }
            }
            if($value=='emp_sign'){
                
                $query = "UPDATE `employee_personal_detail` SET `employee_sign_image`='".$url."' WHERE `userid`='".$userid."'";
                if(mysqli_query($conn,$query))
                {
                    $query= "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
                    $result= mysqli_query($conn, $query);
                    $emparray = array();
                    if(mysqli_num_rows($result) > 0){  
                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            $emparray[] = $row;
                        }
                        echo json_encode(array( "status" => "true","message" => "Successfully file added!" , "data" => $emparray) );
                    }
                    else
                    {
                 		echo json_encode(array( "status" => "false","message" => "Failed!") );
                    }
    		   
                }
                else{
                	echo json_encode(array( "status" => "false","message" => "Failed!") );
                }
                
            }
            if($value=='aadhar_card'){
                
                $query = "UPDATE `employee_personal_detail` SET `aadhar_card_image`='".$url."' WHERE `userid`='".$userid."'";
                if(mysqli_query($conn,$query))
                {
                    $query= "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
                    $result= mysqli_query($conn, $query);
                    $emparray = array();
                    if(mysqli_num_rows($result) > 0){  
                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            $emparray[] = $row;
                        }
                        echo json_encode(array( "status" => "true","message" => "Successfully file added!" , "data" => $emparray) );
                    }
                    else
                    {
                 		echo json_encode(array( "status" => "false","message" => "Failed!") );
                    }
    		   
                }
                else{
                	echo json_encode(array( "status" => "false","message" => "Failed!") );
                }
                
            }
            if($value=='pan_card'){
                
                $query = "UPDATE `employee_personal_detail` SET `pan_card_image`='".$url."' WHERE `userid`='".$userid."'";
                if(mysqli_query($conn,$query))
                {
                    $query= "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
                    $result= mysqli_query($conn, $query);
                    $emparray = array();
                    if(mysqli_num_rows($result) > 0){  
                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            $emparray[] = $row;
                        }
                        echo json_encode(array( "status" => "true","message" => "Successfully file added!" , "data" => $emparray) );
                    }
                    else
                    {
                 		echo json_encode(array( "status" => "false","message" => "Failed!") );
                    }
    		   
                }
                else{
                	echo json_encode(array( "status" => "false","message" => "Failed!") );
                }
            }
            if($value=='bank_proof'){
                
                $query = "UPDATE `employee_personal_detail` SET `bank_proof_image`='".$url."' WHERE `userid`='".$userid."'";
                if(mysqli_query($conn,$query))
                {
                    $query= "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
                    $result= mysqli_query($conn, $query);
                    $emparray = array();
                    if(mysqli_num_rows($result) > 0){  
                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            $emparray[] = $row;
                        }
                        echo json_encode(array( "status" => "true","message" => "Successfully file added!" , "data" => $emparray) );
                    }
                    else
                    {
                 		echo json_encode(array( "status" => "false","message" => "Failed!") );
                    }
    		   
                }
                else{
                	echo json_encode(array( "status" => "false","message" => "Failed!") );
                }
            }
            if($value=='cmp_last_exp'){
                
                $query = "UPDATE `employee_personal_detail` SET `last_company_exp_letter_image`='".$url."' WHERE `userid`='".$userid."'";
                if(mysqli_query($conn,$query))
                {
                    $query= "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
                    $result= mysqli_query($conn, $query);
                    $emparray = array();
                    if(mysqli_num_rows($result) > 0){  
                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            $emparray[] = $row;
                        }
                        echo json_encode(array( "status" => "true","message" => "Successfully file added!" , "data" => $emparray) );
                    }
                    else
                    {
                 		echo json_encode(array( "status" => "false","message" => "Failed!") );
                    }
    		   
                }
                else{
                	echo json_encode(array( "status" => "false","message" => "Failed!") );
                }
                
            }
            if($value=='pay_slip'){
                
                $query = "UPDATE `employee_personal_detail` SET `pay_slip_exp_letter_image`='".$url."' WHERE `userid`='".$userid."'";
                if(mysqli_query($conn,$query))
                {
                    $query= "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
                    $result= mysqli_query($conn, $query);
                    $emparray = array();
                    if(mysqli_num_rows($result) > 0){  
                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            $emparray[] = $row;
                        }
                        echo json_encode(array( "status" => "true","message" => "Successfully file added!" , "data" => $emparray) );
                    }
                    else
                    {
                 		echo json_encode(array( "status" => "false","message" => "Failed!") );
                    }
    		   
                }
                else{
                	echo json_encode(array( "status" => "false","message" => "Failed!") );
                }
                
            }
            if($value=='resign_mail'){
                
                $query = "UPDATE `employee_personal_detail` SET `resign_mail_image`='".$url."' WHERE `userid`='".$userid."'";
                if(mysqli_query($conn,$query))
                {
                    $query= "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
                    $result= mysqli_query($conn, $query);
                    $emparray = array();
                    if(mysqli_num_rows($result) > 0){  
                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            $emparray[] = $row;
                        }
                        echo json_encode(array( "status" => "true","message" => "Successfully file added!" , "data" => $emparray) );
                    }
                    else
                    {
                 		echo json_encode(array( "status" => "false","message" => "Failed!") );
                    }
    		   
                }
                else{
                	echo json_encode(array( "status" => "false","message" => "Failed!") );
                }
                
            }
            if($value=='bank_stmt'){
                
                $query = "UPDATE `employee_personal_detail` SET `bank_stmt_last_3_mth_image`='".$url."' WHERE `userid`='".$userid."'";
                if(mysqli_query($conn,$query))
                {
                    $query= "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
                    $result= mysqli_query($conn, $query);
                    $emparray = array();
                    if(mysqli_num_rows($result) > 0){  
                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            $emparray[] = $row;
                        }
                        echo json_encode(array( "status" => "true","message" => "Successfully file added!" , "data" => $emparray) );
                    }
                    else
                    {
                 		echo json_encode(array( "status" => "false","message" => "Failed!") );
                    }
    		   
                }
                else{
                	echo json_encode(array( "status" => "false","message" => "Failed!") );
                }
                
            }
            if($value=='offer_letter'){
                
                $query = "UPDATE `employee_personal_detail` SET `offer_letter_image`='".$url."' WHERE `userid`='".$userid."'";
                if(mysqli_query($conn,$query))
                {
                    $query= "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
                    $result= mysqli_query($conn, $query);
                    $emparray = array();
                    if(mysqli_num_rows($result) > 0){  
                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            $emparray[] = $row;
                        }
                        echo json_encode(array( "status" => "true","message" => "Successfully file added!" , "data" => $emparray) );
                    }
                    else
                    {
                 		echo json_encode(array( "status" => "false","message" => "Failed!") );
                    }
    		   
                }
                else{
                	echo json_encode(array( "status" => "false","message" => "Failed!") );
                }
                
            }
        
            if($value=='other_documents'){
                
                $query = "UPDATE `employee_personal_detail` SET `other_documents_pdf`='".$url."' WHERE `userid`='".$userid."'";
                if(mysqli_query($conn,$query))
                {
                    $query= "SELECT * FROM `employee_personal_detail` WHERE `userid` = '".$userid."' limit 1";
                    $result= mysqli_query($conn, $query);
                    $emparray = array();
                    if(mysqli_num_rows($result) > 0){  
                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            $emparray[] = $row;
                        }
                        echo json_encode(array( "status" => "true","message" => "Successfully file added!" , "data" => $emparray) );
                    }
                    else
                    {
                 		echo json_encode(array( "status" => "false","message" => "Failed!") );
                    }
    		   
                }
                else{
                	echo json_encode(array( "status" => "false","message" => "Failed!") );
                }
                
            }
            
        }
        else{
        	echo json_encode(array( "status" => "false","message" => "Failed!") );
        }
    }
    else{
        echo json_encode(array( "status" => "false","message" => "Failed!") );
    }
?>