<?php
    
    include 'init.php';
    //set time zone
    date_default_timezone_set("Asia/Calcutta");

    $userid = $_POST['userid'];
    
    if(isset($userid)){
        //get experience data
        $experience_data = "";
        $get_experience_sql = "SELECT * FROM `employee_experience_table` WHERE `userid` = '".$userid."' order by id desc";
    	$result = $conn->query($get_experience_sql);
    	if($result->num_rows > 0){
    	    $experience_data = "Yes";
    	}
    	
    	//get insurance data
    	$insurance_data = "";
        $get_insurance_sql = "SELECT * FROM `employee_insurance_table` WHERE `userid` = '".$userid."' order by id desc";
    	$insurance_result = $conn->query($get_insurance_sql);
    	if($insurance_result->num_rows > 0){
    	    $insurance_data = "Yes";
    	}
    	
    	//get user data
        $data_records = mysqli_query($conn,"SELECT * FROM add_users as t1, `employee_personal_detail` as t2 where t1.userid = t2.userid AND t1.userid ='$userid' limit 1");
        if($data_records->num_rows > 0)
        {
            while($data_record = mysqli_fetch_array($data_records))
            {
                $candidate_category = $data_record['candidate_category'];
                $employee_level = $data_record['employee_level'];
                $salary = $data_record['salary'];
            
                $user_name = $data_record['name'];
                $email = $data_record['email'];
                $number = $data_record['number'];
                $father_name = $data_record['father_name'];
                $joining_date = $data_record['joining_date'];
                $gender = $data_record['gender'];
                $blood_group = $data_record['blood_group'];
                $aadhar_no = $data_record['aadhar_no'];
                $pan_no = $data_record['pan_no'];
                $marital_status = $data_record['marital_status'];
                $pin_code = $data_record['pin_code'];
                $permanent_address = $data_record['permanent_address'];
                $current_address = $data_record['current_address'];
                
                //bank parmas
                $bank_account_no = $data_record['bank_account_no'];
                $bank_ifsc = $data_record['bank_ifsc'];
                
                //PF params
                $uan_no = $data_record['uan_no'];
                $esic_no = $data_record['esic_no'];
                
                //company details params
                $work_with_company = $data_record['work_with_company'];
                $work_with_company_department = $data_record['work_with_company_department'];
                $work_with_company_designation = $data_record['work_with_company_designation'];
                $work_with_company_doj = $data_record['work_with_company_doj'];
                $work_with_company_dol = $data_record['work_with_company_dol'];
                
                $company_relation = $data_record['company_relation'];
                $company_relation_name = $data_record['company_relation_name'];
                $company_relation_relation = $data_record['company_relation_relation'];
                $company_relation_designation = $data_record['company_relation_designation'];
                
                //emergency contatct params
                $person_name = $data_record['person_name'];
                $person_number = $data_record['person_number'];
                $person_relation = $data_record['person_relation'];
                
                //education params
                $s_school = $data_record['10_school'];
                $s_board = $data_record['10_board'];
                $s_percentage = $data_record['10_percentage'];
                $s_year_passing = $data_record['10_year_passing'];
                $s_image = $data_record['10_image'];
                
                $ss_choice = $data_record['12_choice'];
                $ss_school = $data_record['12_school'];
                $ss_board = $data_record['12_board'];
                $ss_percentage = $data_record['12_percentage'];
                $ss_year_passing = $data_record['12_year_passing'];
                $ss_image = $data_record['12_image'];
                
                $g_choice = $data_record['graduation_choice'];
                $g_university = $data_record['graduation_university'];
                $g_board = $data_record['graduation_board'];
                $g_percentage = $data_record['graduation_percentage'];
                $g_year_passing = $data_record['graduation_year_passing'];
                $g_image = $data_record['graduation_image'];
                
                $pg_choice = $data_record['post_graduation_choice'];
                $pg_university = $data_record['post_graduation_university'];
                $pg_board = $data_record['post_graduation_board'];
                $pg_percentage = $data_record['post_graduation_percentage'];
                $pg_year_passing = $data_record['post_graduation_year_passing'];
                $pg_image = $data_record['post_graduation_image'];
                
                $other_choice = $data_record['other_qualification_choice'];
                $other_university = $data_record['other_qualification_university'];
                $other_board = $data_record['other_qualification_board'];
                $other_percentage = $data_record['other_qualification_percentage'];
                $other_year_passing = $data_record['other_qualification_year_passing'];
                $other_image = $data_record['other_qualification_image'];
                
                //nominee variable
                $father_amount = $data_record['father_amount'];
                $mother_amount = $data_record['mother_amount'];
                $wife_amount = $data_record['wife_amount'];
                $guardian_amount = $data_record['guardian_amount'];
                $sibling_amount = $data_record['sibling_amount'];
                $child_one_amount = $data_record['child_one_amount'];
                $child_two_amount = $data_record['child_two_amount'];
                
                //insurance params
                $member_included_for_insurance = $data_record['member_included_for_insurance'];
                
                //document params
                $pp_image = $data_record['passport_size_image'];
                $es_image = $data_record['employee_sign_image'];
                $ac_image = $data_record['aadhar_card_image'];
                $ac_back_image = $data_record['aadhar_card_back_image'];
                $pc_image = $data_record['pan_card_image'];
                $bp_image = $data_record['bank_proof_image'];
                
               
                $lcep_image = $data_record['last_company_exp_letter_image'];
                $psel_image = $data_record['pay_slip_exp_letter_image'];
                $psel_second_image = $data_record['pay_slip_second_last_month_image'];
                $psel_third_image = $data_record['pay_slip_third_last_month_image'];
                $rm_image = $data_record['resign_mail_image'];
                $bslm_image = $data_record['bank_stmt_last_3_mth_image'];
                $offer_letter_image = $data_record['offer_letter_image'];
                $vaccine_image = $data_record['vaccine_certificate_image'];
                
                //request
                $request = $data_record['request'];
            
                //check nominee amount sum 
                $father_amount_num = (float)$father_amount;
                $mother_amount_num = (float)$mother_amount;
                $wife_amount_num = (float)$wife_amount;
                $guardian_amount_num = (float)$guardian_amount;
                $sibling_amount_num = (float)$sibling_amount;
                $child_one_amount_num = (float)$child_one_amount;
                $child_two_amount_num = (float)$child_two_amount;
                
                $total_amount = $father_amount_num + $mother_amount_num + $wife_amount_num + $guardian_amount_num + $sibling_amount_num + $child_one_amount_num + $child_two_amount_num;

                $salary_amount = (double)$salary;
                
                if($user_name=='' && $father_name=='' && $person_name=='' && $person_number==''){
                    echo 'Please fill all the personal details !!!';
                }
                else if($s_school==''){
                    echo 'Please fill all the qualification details !!!';
                }
                else if($total_amount != 100){
                    echo 'Please fill the nominee details !!!';
                }
                else if($candidate_category == 'Fresher' && ($pp_image=='' || $es_image=='' || $ac_image=='' || $ac_back_image=='' || $pc_image=='' || $bp_image=='' || $vaccine_image=='')){
                    echo 'Please fill all the document details !!!';
                }
                else if($candidate_category == 'Experienced' && ($pp_image=='' || $es_image=='' || $ac_image=='' || $ac_back_image=='' || $pc_image=='' || $bp_image=='' || $psel_image=='' || $psel_second_image=='' || $psel_third_image=='' || $rm_image=='' || $bslm_image=='' || $vaccine_image=='')){
                    echo 'Please fill all the document details !!!';
                }
                else if($employee_level == 'Above VBA' && $offer_letter_image ==''){
                    echo 'Please fill all the document details !!!';
                }
                else if($salary_amount >= 21000 && $member_included_for_insurance ==''){
                    echo 'Please fill the insurance details !!!';
                }
                else if($salary_amount >= 21000 && $member_included_for_insurance =='Yes' && $insurance_data == ''){
                    echo 'Please add members in company insurance policy !!!';
                }
                else if($candidate_category == 'Experienced' && $experience_data == ''){
                    echo 'Please fill the experience details !!!';
                }
                else{
                    if($request==''){
                        $generation_time = date('Y-m-d H:i:s');
                        $update_sql = "UPDATE employee_personal_detail SET `request` = 'Pending', `request_generation_date` = '".$generation_time."' WHERE userid ='$userid'";
                        if(mysqli_query($conn, $update_sql)){
                            echo 'Request has been submitted successfully !!!';
                        }
                    }
                    else{
                        echo 'Request has already been submitted';
                    }
                }
            }
        }
        else{
            echo 'Please fill personal details first!!!';
        }   
    }
    
    mysqli_close($conn);
?>